# TODOs

- [x] set prepare-commit-msg hook
- [] show "new version available" message, look into this commit e146d4d cli.ts file
- [] make bundle smaller by properly configuring esbuild
- [] [build for both mjs and cjs](https://snyk.io/blog/best-practices-create-modern-npm-package/)
- [] do // TODOs in the code
- [x] batch small files in one request
- [] add tests
- [] optimize prompt, maybe no prompt would be cleaner
- [] try setting max commit msg length, maybe it will make commits short and more concise
