export enum COMMANDS {
  config = 'config',
  hook = 'hook',
  commitlint = 'commitlint'
}
